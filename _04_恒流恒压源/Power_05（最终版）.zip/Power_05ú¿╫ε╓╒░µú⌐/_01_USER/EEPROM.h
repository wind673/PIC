/* 
 * File:   EEPROM.h
 * Author: SuiFeng
 *
 * Created on 2015��12��12��, ����11:25
 */

#ifndef EEPROM_H
#define	EEPROM_H

#ifdef	__cplusplus
extern "C" {
#endif

#define EEPROM_BYTE_VALUE 1024
    
unsigned char EEPROM_Reads(unsigned int Addr, unsigned char *DateBuff, unsigned int length);
unsigned char EEPROM_Writers(unsigned int Addr, unsigned char *DateBuff, unsigned int length);
void EEPROM_WriterChannelDate(void);
void EEPROM_ReadChannelDate(void);

#ifdef	__cplusplus
}
#endif

#endif	/* EEPROM_H */

